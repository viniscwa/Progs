#define POINT_H

typedef struct To4ka {
    int x;
    int y;
} T_t;

void xy(T_t t1, T_t t2);
void st(T_t t1, T_t t2, T_t t3);